// Interaksi ringan: tahun footer dan animasi masuk saat elemen terlihat.
document.addEventListener("DOMContentLoaded", () => {
  const items = document.querySelectorAll(".info-card, .interest-card, .gallery-item");
  if (!("IntersectionObserver" in window)) return;
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  items.forEach((item) => {
    item.style.opacity = "0";
    item.style.transform = "translateY(14px)";
    item.style.transition = "opacity .6s ease, transform .6s ease";
    observer.observe(item);
  });
  const style = document.createElement("style");
  style.textContent = ".is-visible{opacity:1!important;transform:translateY(0)!important}";
  document.head.appendChild(style);
});
